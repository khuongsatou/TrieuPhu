<?php $__env->startSection('page_content'); ?>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>
            <?php if(isset($cauHinhTroGiup)): ?>
                Cập Nhật Cấu Hình Trợ Giúp
            <?php else: ?>
                Thêm Cấu Hình Trợ Giúp
            <?php endif; ?>
            </h2>
          <ul class="nav navbar-right panel_toolbox">
            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
            </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
              <ul class="dropdown-menu" role="menu">
               <!-- Setting -->
              </ul>
            </li>
            <li><a class="close-link"><i class="fa fa-close"></i></a>
            </li>
          </ul>
          <div class="clearfix"></div>
        </div>
        <div class="x_content">
          <br />

        <?php if(isset($cauHinhTroGiup)): ?>
        <form action="<?php echo e(route('cau_hinh_tro_giup.xu_li_cap_nhat',['id'=>$cauHinhTroGiup->id])); ?>" method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
        <?php else: ?>
        <form action="<?php echo e(route('cau_hinh_tro_giup.xu_li_them')); ?>" method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
        <?php endif; ?>
        
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="loai_tro_giup">Loại trợ giúp: <span class="required">*</span>
              </label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <input name="loai_tro_giup" type="text" id="loai_tro_giup" required="required" class="form-control col-md-7 col-xs-12" 
                <?php if(isset($cauHinhTroGiup)): ?>
                    value="<?php echo e($cauHinhTroGiup->loai_tro_giup); ?>"
                <?php endif; ?> 
                >
              </div>
            </div>

            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="thu_tu">Thứ Tự: <span class="required">*</span>
              </label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <input name="thu_tu" type="number" id="thu_tu" required="required" class="form-control col-md-7 col-xs-12" 
                <?php if(isset($cauHinhTroGiup)): ?>
                    value="<?php echo e($cauHinhTroGiup->thu_tu); ?>"
                <?php endif; ?> 
                >
              </div>
            </div>


            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="credit">Credit: <span class="required">*</span>
              </label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <input name="credit" type="text" id="credit" required="required" class="form-control col-md-7 col-xs-12" 
                <?php if(isset($cauHinhTroGiup)): ?>
                    value="<?php echo e($cauHinhTroGiup->credit); ?>"
                <?php endif; ?> 
                >
              </div>
            </div>

           
           
            <div class="ln_solid"></div>
            <div class="form-group">
              <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                <a href="<?php echo e(route('cau_hinh_tro_giup.danh_sach')); ?>" class="btn btn-danger" type="button">Hủy</a>
                <?php if(!isset($cauHinhTroGiup)): ?>
                  <a href="" class="btn btn-primary" type="reset">Clear</a>
                <?php endif; ?>
                <button type="submit" class="btn btn-success">
                    <?php if(isset($cauHinhTroGiup)): ?>
                        Cập Nhật
                    <?php else: ?>
                        Thêm
                    <?php endif; ?>
                </button>
              </div>
            </div>

          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProjectAndroid\laravel\resources\views/cau_hinh_tro_giup/xl_cau_hinh_tro_giup.blade.php ENDPATH**/ ?>