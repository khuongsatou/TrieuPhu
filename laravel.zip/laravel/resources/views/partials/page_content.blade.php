<div class="right_col" role="main">
          <!-- top tiles -->
          @yield('page_content')
</div>