<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GoiCredit extends Model
{
    //
    protected $table = "goi_credit";
}
