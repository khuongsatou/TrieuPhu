<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LichSuMuaCredit extends Model
{
    //
    protected $table = "lich_su_mua_credit";
}
