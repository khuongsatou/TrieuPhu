<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuanTriVien extends Model
{
    //
    protected $table = "quan_tri_vien";
}
